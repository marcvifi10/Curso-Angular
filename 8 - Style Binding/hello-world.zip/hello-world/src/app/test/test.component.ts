import { Component, OnInit } from '@angular/core';

@Component({
  selector: '[app-test]',
  templateUrl: `
	<h2>Welcome {{name}}</h2>
	<h2 [style.color]="'orange'">Welcome {{name}}</h2>
	<h2 [style.color]="hasError ? 'red' : 'green'">Welcome {{name}}</h2>
	<h2 [style.color]="highlightColor">Welcome {{name}}</h2>
	<h2 [style.color]="blue">Welcome {{name}}</h2>
	<h2 [ngStyle]="titleStyles">Welcome {{name}}</h2>
	`,
  styleUrls: []
})
export class TestComponent implements OnInit {

	public name = "Ejemplo";
	public successClass = "text-success";
	public hasError = true;
	public isSpecial = true;
	public highlightColor = "orange";
	public titleStyles = {
		
		color: "blue",
		fontStyle: "italic"
		
	};
	
  constructor() { }

  ngOnInit() {
  }
  
  greetUser()
  {
	  
	  return "Hello " + this.name;
	  
  }

}
