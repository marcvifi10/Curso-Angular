import { Component, OnInit } from '@angular/core';

@Component({
  selector: '[app-test]',
  templateUrl: `
	<h2>Welcome {{name}}</h2>
	<h3>{{2+2}}</h3>
	<h3>{{ "Welcome " + name }}</h3>
	<h3>{{ name.length }}</h3>
	<h3>{{ name.toUpperCase }}</h3>
	<h2>{{ greetUser() }}</h2>
	<h2>{{ siteUrl }}</h2>
	`,
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {

	public name = "Ejemplo";
	public siteUrl = window.location.href;
	

  constructor() { }

  ngOnInit() {
  }
  
  greetUser()
  {
	  
	  return "Hello " + this.name;
	  
  }

}
