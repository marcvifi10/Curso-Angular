import { Component, OnInit } from '@angular/core';

@Component({
  selector: '[app-test]',
  templateUrl: `
	<h2>Welcome {{name}}</h2>
	<input #myInput type="text">
	<button (click)="logMessage(myInput)">Log</button>
	`,
  styles: []
})
export class TestComponent implements OnInit {

	public name = "Ejemplo";
	public successClass = "text-success";
	public hasError = true;
	public isSpecial = true;
	public highlightColor = "orange";
	public greeting = "";
	public titleStyles = {
		
		color: "blue",
		fontStyle: "italic"
		
	};
	
  constructor() { }

  ngOnInit() {
  }
  
  greetUser()
  {
	  
	  return "Hello " + this.name;
	  
  }
  
  logMessage(value)
  {
	   console.log(value)
  }

}
