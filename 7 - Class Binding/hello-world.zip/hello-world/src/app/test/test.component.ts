import { Component, OnInit } from '@angular/core';

@Component({
  selector: '[app-test]',
  templateUrl: `
	<h2 class="text-success">Welcome {{name}}</h2>
	<h2 class="text-danger">Welcome {{name}}</h2>
	<h2 class="text-special">Welcome {{name}}</h2>
	<h2 [class]="successClass">Welcome {{name}}</h2>
	<h2 class="text-special" [class]="successClass">Welcome {{name}}</h2>
	<h2 [class.text-danger]="hasError">Welcome {{name}}</h2>
	<h2 [ngClass]="messageClasses">Welcome {{name}}</h2>
	`,
  styleUrls: [`
  
	.text-success
	{
		color: green;
	}
	
	.text-danger
	{
		color: red;
	}
	
	.text-special
	{
		font-style: italic;
	}
  
  `]
})
export class TestComponent implements OnInit {

	public name = "Ejemplo";
	public successClass = "text-success";
	public hasError = true;
	public isSpecial = true;
	public messageClasses = 
	{
		
		"text-success": !this.hasError,
		"text-danger": this.hasError,
		"text-special": this.isSpecial
		
	}

  constructor() { }

  ngOnInit() {
  }
  
  greetUser()
  {
	  
	  return "Hello " + this.name;
	  
  }

}
