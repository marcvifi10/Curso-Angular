import { Component, OnInit } from '@angular/core';

@Component({
  selector: '[app-test]',
  template: `
		
		<div [ngSwitch]="color">
			<div *ngSwitchCase="'red'">Rojo</div>
			<div *ngSwitchCase="'blue'">Azul</div>
			<div *ngSwitchCase="'green'">Verde</div>
			<div *ngSwitchDefault>Otra vez</div>
		</div>
		
	`,
  styles: []
})
export class TestComponent implements OnInit {

	public color = "red";
	
  constructor() { }

  ngOnInit() {
  }
  
  greetUser()
  {
	  
	  return "Hello " + this.name;
	  
  }
  
  logMessage(value)
  {
	   console.log(value)
  }

}
