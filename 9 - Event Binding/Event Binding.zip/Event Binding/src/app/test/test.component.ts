import { Component, OnInit } from '@angular/core';

@Component({
  selector: '[app-test]',
  templateUrl: `
	<h2>Welcome {{name}}</h2>
	<h2 [style.color]="'orange'">Welcome {{name}}</h2>
	<h2 [style.color]="hasError ? 'red' : 'green'">Welcome {{name}}</h2>
	<h2 [style.color]="highlightColor">Welcome {{name}}</h2>
	<h2 [style.color]="blue">Welcome {{name}}</h2>
	<h2 [ngStyle]="titleStyles">Welcome {{name}}</h2>
	<button (click)="onClick()">Greet</button>
	<button (click)="onClick2($event)">Greet</button>
	<button (click)="greetin='Welcome'">Greet</button>
	{{greeting}}
	`,
  styleUrls: []
})
export class TestComponent implements OnInit {

	public name = "Ejemplo";
	public successClass = "text-success";
	public hasError = true;
	public isSpecial = true;
	public highlightColor = "orange";
	public greeting = "";
	public titleStyles = {
		
		color: "blue",
		fontStyle: "italic"
		
	};
	
  constructor() { }

  ngOnInit() {
  }
  
  greetUser()
  {
	  
	  return "Hello " + this.name;
	  
  }
  
  onClick()
  {
	  
	  console.log('Click!!!');
	  this.greeting = 'Welcome';
	  
  }
  
  onClick2(event)
  {
	  
	  console.log(event);
	  this.greeting = event.type;
	  
  }

}
