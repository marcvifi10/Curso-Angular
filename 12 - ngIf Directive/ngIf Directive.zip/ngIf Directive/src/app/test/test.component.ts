import { Component, OnInit } from '@angular/core';

@Component({
  selector: '[app-test]',
  template: `
		<h2 *ngIf="true">Codevolution</h2>
		<h2 *ngIf="false">Codevolution</h2>
		<h2 *ngIf="displayName; else elseBlock">
			Codevolution
		</h2>
		<ng-template #elseBlock>
			<h2>Name is hidden</h2>
		</ng-template>
		<div *ngIf="displayName; then thenBlock; else elseBlock"></div>
		<ng-template #thenBlock>
			<h2>Name</h2>
		</ng-template>
		<ng-template #elseBlock>
			<h2>Hidden</h2>
		</ng-template>
		
	`,
  styles: []
})
export class TestComponent implements OnInit {

	displayName = true;
	
  constructor() { }

  ngOnInit() {
  }
  
  greetUser()
  {
	  
	  return "Hello " + this.name;
	  
  }
  
  logMessage(value)
  {
	   console.log(value)
  }

}
